<?php
class PublishersController extends ClippingAppController {

	var $name = 'Publishers';

	function index() {
		$this->Publisher->recursive = 0;
		$this->set('publishers', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid publisher', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('publisher', $this->Publisher->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Publisher->create();
			if ($this->Publisher->save($this->data)) {
				$this->Session->setFlash(__('The publisher has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The publisher could not be saved. Please, try again.', true));
			}
		}
		$publisherTypes = $this->Publisher->PublisherType->find('list');
		$sections = $this->Publisher->Section->find('list');
		$this->set(compact('publisherTypes', 'sections'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid publisher', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Publisher->save($this->data)) {
				$this->Session->setFlash(__('The publisher has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The publisher could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Publisher->read(null, $id);
		}
		$publisherTypes = $this->Publisher->PublisherType->find('list');
		$sections = $this->Publisher->Section->find('list');
		$this->set(compact('publisherTypes', 'sections'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for publisher', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Publisher->delete($id)) {
			$this->Session->setFlash(__('Publisher deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Publisher was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	function admin_index() {
		$this->Publisher->recursive = 0;
		$this->set('publishers', $this->paginate());
	}

	function admin_view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid publisher', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('publisher', $this->Publisher->read(null, $id));
	}

	function admin_add() {
		if (!empty($this->data)) {
			$this->Publisher->create();
			if ($this->Publisher->save($this->data)) {
				$this->Session->setFlash(__('The publisher has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The publisher could not be saved. Please, try again.', true));
			}
		}
		$publisherTypes = $this->Publisher->PublisherType->find('list');
		$sections = $this->Publisher->Section->find('list');
		$this->set(compact('publisherTypes', 'sections'));
	}

	function admin_edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid publisher', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Publisher->save($this->data)) {
				$this->Session->setFlash(__('The publisher has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The publisher could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Publisher->read(null, $id);
		}
		$publisherTypes = $this->Publisher->PublisherType->find('list');
		$sections = $this->Publisher->Section->find('list');
		$this->set(compact('publisherTypes', 'sections'));
	}

	function admin_delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for publisher', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Publisher->delete($id)) {
			$this->Session->setFlash(__('Publisher deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Publisher was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
}
?>