<?php
class FilesController extends ClippingAppController {

	var $name = 'Files';
	var $scaffold;

}
?>