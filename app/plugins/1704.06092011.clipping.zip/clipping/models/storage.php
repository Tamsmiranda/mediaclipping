<?php
class Storage extends ClippingAppModel {
	var $name = 'Storage';
	var $displayField = 'name';
	var $actsAs = array(
		'MeioUpload.MeioUpload' => array(
			'file' => array(
				'dir' => 'files{DS}storage{DS}',
				'create_directory' => true,
				//'allowed_mime' => array(),
				//'allowed_ext' => array(),
				/*'thumbsizes' => array(
					'320x90' => array(
                        'width' => 320,
                        'height' => 90,
						'forceAspectRatio' => 'C',
                    )
				),*/
			)
		)
	);
	//The Associations below have been created with all possible keys, those that are not needed can be removed
	

	var $belongsTo = array(
		'Clipp' => array(
			'className' => 'Clipp',
			'foreignKey' => 'clipp_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);
}
?>