<?php
/* File Test cases generated on: 2011-09-06 13:32:12 : 1315315932*/
App::import('Model', 'Clipping.File');

class FileTestCase extends CakeTestCase {
	function startTest() {
		$this->File =& ClassRegistry::init('File');
	}

	function endTest() {
		unset($this->File);
		ClassRegistry::flush();
	}

	function testCreate() {

	}

	function testOpen() {

	}

	function testRead() {

	}

	function testOffset() {

	}

	function testPrepare() {

	}

	function testWrite() {

	}

	function testAppend() {

	}

	function testClose() {

	}

	function testDelete() {

	}

	function testInfo() {

	}

	function testExt() {

	}

	function testName() {

	}

	function testSafe() {

	}

	function testMd5() {

	}

	function testPwd() {

	}

	function testExist() {

	}

	function testPerm() {

	}

	function testSize() {

	}

	function testWritable() {

	}

	function testExecutable() {

	}

	function testReadable() {

	}

	function testOwner() {

	}

	function testGroup() {

	}

	function testLastAccess() {

	}

	function testLastChange() {

	}

	function testFolder() {

	}

	function testCopy() {

	}

}
?>