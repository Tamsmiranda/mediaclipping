<?php

class ClippingAppModel extends AppModel {

var $actsAs = array('Clipping.WhoDidIt');

}

?>