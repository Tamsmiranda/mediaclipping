<?php

class ClippingAppController extends AppController {

}

?>