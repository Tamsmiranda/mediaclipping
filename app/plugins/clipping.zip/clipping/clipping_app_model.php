<?php

class ClippingAppModel extends AppModel {

}

?>