<?php
/* ClippEvaluations Test cases generated on: 2011-08-29 19:24:29 : 1314645869*/
App::import('Controller', 'Clipping.ClippEvaluations');

class TestClippEvaluationsController extends ClippEvaluationsController {
	var $autoRender = false;

	function redirect($url, $status = null, $exit = true) {
		$this->redirectUrl = $url;
	}
}

class ClippEvaluationsControllerTestCase extends CakeTestCase {
	var $fixtures = array('');

	function startTest() {
		$this->ClippEvaluations =& new TestClippEvaluationsController();
		$this->ClippEvaluations->constructClasses();
	}

	function endTest() {
		unset($this->ClippEvaluations);
		ClassRegistry::flush();
	}

}
?>