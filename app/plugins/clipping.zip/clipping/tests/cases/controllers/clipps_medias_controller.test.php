<?php
/* ClippsMedias Test cases generated on: 2011-08-30 19:44:45 : 1314733485*/
App::import('Controller', 'Clipping.ClippsMedias');

class TestClippsMediasController extends ClippsMediasController {
	var $autoRender = false;

	function redirect($url, $status = null, $exit = true) {
		$this->redirectUrl = $url;
	}
}

class ClippsMediasControllerTestCase extends CakeTestCase {
	function startTest() {
		$this->ClippsMedias =& new TestClippsMediasController();
		$this->ClippsMedias->constructClasses();
	}

	function endTest() {
		unset($this->ClippsMedias);
		ClassRegistry::flush();
	}

}
?>