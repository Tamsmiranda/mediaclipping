<?php
/* ClippStatuses Test cases generated on: 2011-08-29 19:24:53 : 1314645893*/
App::import('Controller', 'Clipping.ClippStatuses');

class TestClippStatusesController extends ClippStatusesController {
	var $autoRender = false;

	function redirect($url, $status = null, $exit = true) {
		$this->redirectUrl = $url;
	}
}

class ClippStatusesControllerTestCase extends CakeTestCase {
	function startTest() {
		$this->ClippStatuses =& new TestClippStatusesController();
		$this->ClippStatuses->constructClasses();
	}

	function endTest() {
		unset($this->ClippStatuses);
		ClassRegistry::flush();
	}

}
?>