<?php
/* Clipps Test cases generated on: 2011-08-29 19:25:07 : 1314645907*/
App::import('Controller', 'Clipping.Clipps');

class TestClippsController extends ClippsController {
	var $autoRender = false;

	function redirect($url, $status = null, $exit = true) {
		$this->redirectUrl = $url;
	}
}

class ClippsControllerTestCase extends CakeTestCase {
	function startTest() {
		$this->Clipps =& new TestClippsController();
		$this->Clipps->constructClasses();
	}

	function endTest() {
		unset($this->Clipps);
		ClassRegistry::flush();
	}

}
?>