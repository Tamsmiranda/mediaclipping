<?php
/* ClippsMediaTypes Test cases generated on: 2011-08-30 19:30:41 : 1314732641*/
App::import('Controller', 'Clipping.ClippsMediaTypes');

class TestClippsMediaTypesController extends ClippsMediaTypesController {
	var $autoRender = false;

	function redirect($url, $status = null, $exit = true) {
		$this->redirectUrl = $url;
	}
}

class ClippsMediaTypesControllerTestCase extends CakeTestCase {
	function startTest() {
		$this->ClippsMediaTypes =& new TestClippsMediaTypesController();
		$this->ClippsMediaTypes->constructClasses();
	}

	function endTest() {
		unset($this->ClippsMediaTypes);
		ClassRegistry::flush();
	}

}
?>