<?php
/* ClippsSections Test cases generated on: 2011-08-30 19:45:15 : 1314733515*/
App::import('Controller', 'Clipping.ClippsSections');

class TestClippsSectionsController extends ClippsSectionsController {
	var $autoRender = false;

	function redirect($url, $status = null, $exit = true) {
		$this->redirectUrl = $url;
	}
}

class ClippsSectionsControllerTestCase extends CakeTestCase {
	var $fixtures = array('');

	function startTest() {
		$this->ClippsSections =& new TestClippsSectionsController();
		$this->ClippsSections->constructClasses();
	}

	function endTest() {
		unset($this->ClippsSections);
		ClassRegistry::flush();
	}

}
?>