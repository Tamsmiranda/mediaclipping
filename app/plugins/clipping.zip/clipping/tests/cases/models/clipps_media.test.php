<?php
/* ClippsMedia Test cases generated on: 2011-08-30 19:27:43 : 1314732463*/
App::import('Model', 'Clipping.ClippsMedia');

class ClippsMediaTestCase extends CakeTestCase {
	function startTest() {
		$this->ClippsMedia =& ClassRegistry::init('ClippsMedia');
	}

	function endTest() {
		unset($this->ClippsMedia);
		ClassRegistry::flush();
	}

}
?>