<?php
/* ClippEvaluation Test cases generated on: 2011-08-29 19:22:22 : 1314645742*/
App::import('Model', 'Clipping.ClippEvaluation');

class ClippEvaluationTestCase extends CakeTestCase {
	function startTest() {
		$this->ClippEvaluation =& ClassRegistry::init('ClippEvaluation');
	}

	function endTest() {
		unset($this->ClippEvaluation);
		ClassRegistry::flush();
	}

}
?>