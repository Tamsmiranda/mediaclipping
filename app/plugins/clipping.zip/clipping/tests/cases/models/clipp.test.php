<?php
/* Clipp Test cases generated on: 2011-08-29 19:21:34 : 1314645694*/
App::import('Model', 'Clipping.Clipp');

class ClippTestCase extends CakeTestCase {
	function startTest() {
		$this->Clipp =& ClassRegistry::init('Clipp');
	}

	function endTest() {
		unset($this->Clipp);
		ClassRegistry::flush();
	}

}
?>