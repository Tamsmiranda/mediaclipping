<?php
/* ClippsSection Test cases generated on: 2011-08-30 19:29:39 : 1314732579*/
App::import('Model', 'Clipping.ClippsSection');

class ClippsSectionTestCase extends CakeTestCase {
	function startTest() {
		$this->ClippsSection =& ClassRegistry::init('ClippsSection');
	}

	function endTest() {
		unset($this->ClippsSection);
		ClassRegistry::flush();
	}

}
?>