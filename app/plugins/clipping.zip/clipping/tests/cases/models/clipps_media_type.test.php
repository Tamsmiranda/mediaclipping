<?php
/* ClippsMediaType Test cases generated on: 2011-08-30 19:26:53 : 1314732413*/
App::import('Model', 'Clipping.ClippsMediaType');

class ClippsMediaTypeTestCase extends CakeTestCase {
	function startTest() {
		$this->ClippsMediaType =& ClassRegistry::init('ClippsMediaType');
	}

	function endTest() {
		unset($this->ClippsMediaType);
		ClassRegistry::flush();
	}

}
?>