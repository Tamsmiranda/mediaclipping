<?php
/* ClippStatus Test cases generated on: 2011-08-29 19:22:44 : 1314645764*/
App::import('Model', 'Clipping.ClippStatus');

class ClippStatusTestCase extends CakeTestCase {
	function startTest() {
		$this->ClippStatus =& ClassRegistry::init('ClippStatus');
	}

	function endTest() {
		unset($this->ClippStatus);
		ClassRegistry::flush();
	}

}
?>