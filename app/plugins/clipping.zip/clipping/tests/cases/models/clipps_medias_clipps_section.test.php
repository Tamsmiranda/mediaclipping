<?php
/* ClippsMediasClippsSection Test cases generated on: 2011-08-30 19:38:08 : 1314733088*/
App::import('Model', 'Clipping.ClippsMediasClippsSection');

class ClippsMediasClippsSectionTestCase extends CakeTestCase {
	function startTest() {
		$this->ClippsMediasClippsSection =& ClassRegistry::init('ClippsMediasClippsSection');
	}

	function endTest() {
		unset($this->ClippsMediasClippsSection);
		ClassRegistry::flush();
	}

}
?>