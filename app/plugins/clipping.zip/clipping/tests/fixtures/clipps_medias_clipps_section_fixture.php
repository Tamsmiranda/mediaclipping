<?php
/* ClippsMediasClippsSection Fixture generated on: 2011-08-30 19:38:06 : 1314733086 */
class ClippsMediasClippsSectionFixture extends CakeTestFixture {
	var $name = 'ClippsMediasClippsSection';

	var $fields = array(
		'id' => array('type' => 'string', 'null' => false, 'default' => NULL, 'length' => 36, 'key' => 'primary', 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'clipps_media_id' => array('type' => 'string', 'null' => true, 'default' => NULL, 'length' => 36, 'key' => 'index', 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'clipps_section_id' => array('type' => 'string', 'null' => true, 'default' => NULL, 'length' => 36, 'key' => 'index', 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1), 'id_UNIQUE' => array('column' => 'id', 'unique' => 1), 'fk_clipps_media_clipps_section_clipps_sections1' => array('column' => 'clipps_section_id', 'unique' => 0), 'fk_clipps_media_clipps_section_clipps_medias1' => array('column' => 'clipps_media_id', 'unique' => 0)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

	var $records = array(
		array(
			'id' => '4e5d3c1e-73a8-4f4f-bab9-1778737253ea',
			'clipps_media_id' => 'Lorem ipsum dolor sit amet',
			'clipps_section_id' => 'Lorem ipsum dolor sit amet'
		),
	);
}
?>