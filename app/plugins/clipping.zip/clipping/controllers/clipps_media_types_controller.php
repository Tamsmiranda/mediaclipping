<?php
class ClippsMediaTypesController extends ClippingAppController {

	var $name = 'ClippsMediaTypes';

	function index() {
		$this->ClippsMediaType->recursive = 0;
		$this->set('clippsMediaTypes', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid clipps media type', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('clippsMediaType', $this->ClippsMediaType->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->ClippsMediaType->create();
			if ($this->ClippsMediaType->save($this->data)) {
				$this->Session->setFlash(__('The clipps media type has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipps media type could not be saved. Please, try again.', true));
			}
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid clipps media type', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->ClippsMediaType->save($this->data)) {
				$this->Session->setFlash(__('The clipps media type has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipps media type could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->ClippsMediaType->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for clipps media type', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->ClippsMediaType->delete($id)) {
			$this->Session->setFlash(__('Clipps media type deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Clipps media type was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	function admin_index() {
		$this->ClippsMediaType->recursive = 0;
		$this->set('clippsMediaTypes', $this->paginate());
	}

	function admin_view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid clipps media type', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('clippsMediaType', $this->ClippsMediaType->read(null, $id));
	}

	function admin_add() {
		if (!empty($this->data)) {
			$this->ClippsMediaType->create();
			if ($this->ClippsMediaType->save($this->data)) {
				$this->Session->setFlash(__('The clipps media type has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipps media type could not be saved. Please, try again.', true));
			}
		}
	}

	function admin_edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid clipps media type', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->ClippsMediaType->save($this->data)) {
				$this->Session->setFlash(__('The clipps media type has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipps media type could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->ClippsMediaType->read(null, $id);
		}
	}

	function admin_delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for clipps media type', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->ClippsMediaType->delete($id)) {
			$this->Session->setFlash(__('Clipps media type deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Clipps media type was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
}
?>