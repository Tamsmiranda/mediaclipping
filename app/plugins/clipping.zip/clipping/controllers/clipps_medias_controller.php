<?php
class ClippsMediasController extends ClippingAppController {

	var $name = 'ClippsMedias';

	function index() {
		$this->ClippsMedia->recursive = 0;
		$this->set('clippsMedias', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid clipps media', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('clippsMedia', $this->ClippsMedia->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->ClippsMedia->create();
			if ($this->ClippsMedia->save($this->data)) {
				$this->Session->setFlash(__('The clipps media has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipps media could not be saved. Please, try again.', true));
			}
		}
		$clippsMediaTypes = $this->ClippsMedia->ClippsMediaType->find('list');
		$clippsSections = $this->ClippsMedia->ClippsSection->find('list');
		$this->set(compact('clippsMediaTypes', 'clippsSections'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid clipps media', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->ClippsMedia->save($this->data)) {
				$this->Session->setFlash(__('The clipps media has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipps media could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->ClippsMedia->read(null, $id);
		}
		$clippsMediaTypes = $this->ClippsMedia->ClippsMediaType->find('list');
		$clippsSections = $this->ClippsMedia->ClippsSection->find('list');
		$this->set(compact('clippsMediaTypes', 'clippsSections'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for clipps media', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->ClippsMedia->delete($id)) {
			$this->Session->setFlash(__('Clipps media deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Clipps media was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	function admin_index() {
		$this->ClippsMedia->recursive = 0;
		$this->set('clippsMedias', $this->paginate());
	}

	function admin_view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid clipps media', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('clippsMedia', $this->ClippsMedia->read(null, $id));
	}

	function admin_add() {
		if (!empty($this->data)) {
			$this->ClippsMedia->create();
			if ($this->ClippsMedia->save($this->data)) {
				$this->Session->setFlash(__('The clipps media has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipps media could not be saved. Please, try again.', true));
			}
		}
		$clippsMediaTypes = $this->ClippsMedia->ClippsMediaType->find('list');
		$clippsSections = $this->ClippsMedia->ClippsSection->find('list');
		$this->set(compact('clippsMediaTypes', 'clippsSections'));
	}

	function admin_edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid clipps media', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->ClippsMedia->save($this->data)) {
				$this->Session->setFlash(__('The clipps media has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipps media could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->ClippsMedia->read(null, $id);
		}
		$clippsMediaTypes = $this->ClippsMedia->ClippsMediaType->find('list');
		$clippsSections = $this->ClippsMedia->ClippsSection->find('list');
		$this->set(compact('clippsMediaTypes', 'clippsSections'));
	}

	function admin_delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for clipps media', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->ClippsMedia->delete($id)) {
			$this->Session->setFlash(__('Clipps media deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Clipps media was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
}
?>