<?php
class ClippsController extends ClippingAppController {

	var $name = 'Clipps';

	function index() {
		$this->Clipp->recursive = 0;
		$this->set('clipps', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid clipp', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('clipp', $this->Clipp->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Clipp->create();
			if ($this->Clipp->save($this->data)) {
				$this->Session->setFlash(__('The clipp has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipp could not be saved. Please, try again.', true));
			}
		}
		$clippEvaluations = $this->Clipp->ClippEvaluation->find('list');
		$clippStatuses = $this->Clipp->ClippStatus->find('list');
		$this->set(compact('clippEvaluations', 'clippStatuses'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid clipp', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Clipp->save($this->data)) {
				$this->Session->setFlash(__('The clipp has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipp could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Clipp->read(null, $id);
		}
		$clippEvaluations = $this->Clipp->ClippEvaluation->find('list');
		$clippStatuses = $this->Clipp->ClippStatus->find('list');
		$this->set(compact('clippEvaluations', 'clippStatuses'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for clipp', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Clipp->delete($id)) {
			$this->Session->setFlash(__('Clipp deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Clipp was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	function admin_index() {
		$this->Clipp->recursive = 0;
		$this->set('clipps', $this->paginate());
	}

	function admin_view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid clipp', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('clipp', $this->Clipp->read(null, $id));
	}

	function admin_add() {
		if (!empty($this->data)) {
			$this->Clipp->create();
			if ($this->Clipp->save($this->data)) {
				$this->Session->setFlash(__('The clipp has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipp could not be saved. Please, try again.', true));
			}
		}
		$clippEvaluations = $this->Clipp->ClippEvaluation->find('list');
		$clippStatuses = $this->Clipp->ClippStatus->find('list');
		$this->set(compact('clippEvaluations', 'clippStatuses'));
	}

	function admin_edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid clipp', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Clipp->save($this->data)) {
				$this->Session->setFlash(__('The clipp has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipp could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Clipp->read(null, $id);
		}
		$clippEvaluations = $this->Clipp->ClippEvaluation->find('list');
		$clippStatuses = $this->Clipp->ClippStatus->find('list');
		$this->set(compact('clippEvaluations', 'clippStatuses'));
	}

	function admin_delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for clipp', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Clipp->delete($id)) {
			$this->Session->setFlash(__('Clipp deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Clipp was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
}
?>