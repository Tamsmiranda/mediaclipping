<?php
class ClippEvaluationsController extends ClippingAppController {

	var $name = 'ClippEvaluations';

	function index() {
		$this->ClippEvaluation->recursive = 0;
		$this->set('clippEvaluations', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid clipp evaluation', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('clippEvaluation', $this->ClippEvaluation->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->ClippEvaluation->create();
			if ($this->ClippEvaluation->save($this->data)) {
				$this->Session->setFlash(__('The clipp evaluation has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipp evaluation could not be saved. Please, try again.', true));
			}
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid clipp evaluation', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->ClippEvaluation->save($this->data)) {
				$this->Session->setFlash(__('The clipp evaluation has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipp evaluation could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->ClippEvaluation->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for clipp evaluation', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->ClippEvaluation->delete($id)) {
			$this->Session->setFlash(__('Clipp evaluation deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Clipp evaluation was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	function admin_index() {
		$this->ClippEvaluation->recursive = 0;
		$this->set('clippEvaluations', $this->paginate());
	}

	function admin_view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid clipp evaluation', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('clippEvaluation', $this->ClippEvaluation->read(null, $id));
	}

	function admin_add() {
		if (!empty($this->data)) {
			$this->ClippEvaluation->create();
			if ($this->ClippEvaluation->save($this->data)) {
				$this->Session->setFlash(__('The clipp evaluation has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipp evaluation could not be saved. Please, try again.', true));
			}
		}
	}

	function admin_edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid clipp evaluation', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->ClippEvaluation->save($this->data)) {
				$this->Session->setFlash(__('The clipp evaluation has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The clipp evaluation could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->ClippEvaluation->read(null, $id);
		}
	}

	function admin_delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for clipp evaluation', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->ClippEvaluation->delete($id)) {
			$this->Session->setFlash(__('Clipp evaluation deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Clipp evaluation was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
}
?>