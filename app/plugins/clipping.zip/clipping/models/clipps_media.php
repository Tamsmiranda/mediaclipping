<?php
class ClippsMedia extends ClippingAppModel {
	var $name = 'ClippsMedia';
	var $displayField = 'name';
	var $validate = array(
		'name' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $belongsTo = array(
		'ClippsMediaType' => array(
			'className' => 'ClippsMediaType',
			'foreignKey' => 'clipps_media_type_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);

	var $hasMany = array(
		'Clipp' => array(
			'className' => 'Clipp',
			'foreignKey' => 'clipps_media_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);


	var $hasAndBelongsToMany = array(
		'ClippsSection' => array(
			'className' => 'ClippsSection',
			'joinTable' => 'clipps_medias_clipps_sections',
			'foreignKey' => 'clipps_media_id',
			'associationForeignKey' => 'clipps_section_id',
			'unique' => true,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
			'deleteQuery' => '',
			'insertQuery' => ''
		)
	);

}
?>