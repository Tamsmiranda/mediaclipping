<?php
class ClippsMediaClippsSection extends ClippingAppModel {
	var $name = 'ClippsMediaClippsSection';
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $belongsTo = array(
		'ClippsMedia' => array(
			'className' => 'ClippsMedia',
			'foreignKey' => 'clipps_media_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'ClippsSection' => array(
			'className' => 'ClippsSection',
			'foreignKey' => 'clipps_section_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);
}
?>